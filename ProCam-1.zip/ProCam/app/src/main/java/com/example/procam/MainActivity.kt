package com.example.procam

import android.Manifest
import android.app.Activity
import android.app.Dialog
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.*
import android.hardware.display.DisplayManager
import android.media.ExifInterface
import android.media.Image
import android.media.ImageReader
import android.media.MediaRecorder
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.util.Size
import android.view.*
import android.widget.*
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sqrt

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val ACCENT = 0xFFFFB300.toInt()
private const val REDC = 0xFFFF3B30.toInt()

enum class Param { ISO, SS, WB, FOCUS, EV, ZOOM }
data class Preset(val label: String, val w: Int, val h: Int, val fps: Int)

class AspectFrame(c: Context) : FrameLayout(c) {
    private var ar = 16f / 9f
    fun setAspect(w: Int, h: Int) { ar = w.toFloat() / h; requestLayout() }
    override fun onMeasure(ws: Int, hs: Int) {
        val pw = MeasureSpec.getSize(ws); val ph = MeasureSpec.getSize(hs)
        val w: Int; val h: Int
        if (pw / ar <= ph) { w = pw; h = (pw / ar).toInt() } else { w = (ph * ar).toInt(); h = ph }
        super.onMeasure(MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY),
            MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY))
    }
}

class OverlayView(c: Context) : View(c) {
    var mask: Bitmap? = null
    var grid = false
    private val gp = Paint().apply { color = 0x88FFFFFF.toInt(); strokeWidth = 2f }
    override fun onDraw(cv: Canvas) {
        mask?.let { cv.drawBitmap(it, null, Rect(0, 0, width, height), null) }
        if (grid) for (i in 1..2) {
            cv.drawLine(width * i / 3f, 0f, width * i / 3f, height.toFloat(), gp)
            cv.drawLine(0f, height * i / 3f, width.toFloat(), height * i / 3f, gp)
        }
    }
}

class HistView(c: Context) : View(c) {
    var bins = IntArray(64)
    private val p = Paint().apply { color = 0xDDFFFFFF.toInt() }
    private val bg = Paint().apply { color = 0x66000000 }
    override fun onDraw(cv: Canvas) {
        cv.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bg)
        var mx = 1
        for (b in bins) if (b > mx) mx = b
        val bw = width / 64f
        for (i in 0 until 64) {
            val h = height * sqrt(bins[i].toFloat() / mx)
            cv.drawRect(i * bw, height - h, (i + 1) * bw - 1f, height.toFloat(), p)
        }
    }
}

class MainActivity : Activity() {
    private lateinit var stage: AspectFrame
    private lateinit var tv: TextureView
    private lateinit var ov: OverlayView
    private lateinit var hist: HistView
    private lateinit var hud: FrameLayout
    private lateinit var cm: CameraManager
    private lateinit var status: TextView
    private lateinit var timerTv: TextView
    private lateinit var audio: ProgressBar
    private lateinit var seekRow: LinearLayout
    private lateinit var seekLabel: TextView
    private lateinit var seek: SeekBar
    private lateinit var autoBtn: TextView
    private lateinit var recInner: View
    private lateinit var lensBtn: TextView
    private lateinit var torchBtn: TextView
    private val chipViews = mutableMapOf<Param, TextView>()
    private var selected: Param? = null
    private var updatingSeek = false

    private val bgThread = HandlerThread("cam").apply { start() }
    private val handler = Handler(bgThread.looper)
    private val ui = Handler(Looper.getMainLooper())

    private var ids = listOf<String>()
    private var idx = 0
    private var lensText = ""
    private var device: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var chars: CameraCharacteristics? = null
    private var builder: CaptureRequest.Builder? = null
    private var previewSurface: Surface? = null
    private var anaSurface: Surface? = null
    private var jpegReader: ImageReader? = null
    private var rawReader: ImageReader? = null
    private var anaReader: ImageReader? = null
    private var rawInSession = false
    private var level = 0
    private var anaCount = 0

    private val presets = mutableListOf<Preset>()
    private var curPreset = 0
    private var previewSize = Size(1920, 1080)

    private var recorder: MediaRecorder? = null
    private var recPfd: ParcelFileDescriptor? = null
    @Volatile private var recording = false
    private var recStart = 0L

    // settings / state
    private var autoExp = true
    private var autoFocus = true
    private var hevc = false
    private var bitrateMbps = 0
    private var zebraOn = false
    private var peakOn = false
    private var histOn = true
    private var gridOn = false
    private var rawOn = false
    private var torchOn = false
    private val prog = mutableMapOf(Param.ISO to 250, Param.SS to 160, Param.WB to 0,
        Param.FOCUS to 0, Param.EV to 50, Param.ZOOM to 0)

    private val wbNames = listOf("WB AUTO", "TUNGSTEN 2800K", "FLUORESCENT 4000K", "DAYLIGHT 5500K", "CLOUDY 6500K")
    private val wbModes = listOf(
        CameraMetadata.CONTROL_AWB_MODE_AUTO, CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT,
        CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT, CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT,
        CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT)

    private val rawLock = Any()
    private var pendingRaw: Image? = null
    private var pendingRes: TotalCaptureResult? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    @Suppress("DEPRECATION") private fun rot() = windowManager.defaultDisplay.rotation

    // ================= UI =================
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        stage = AspectFrame(this)
        tv = TextureView(this); ov = OverlayView(this); hist = HistView(this)
        stage.addView(tv, FrameLayout.LayoutParams(MATCH, MATCH))
        stage.addView(ov, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(stage, FrameLayout.LayoutParams(MATCH, MATCH, Gravity.CENTER))
        hud = FrameLayout(this)
        root.addView(hud, FrameLayout.LayoutParams(MATCH, MATCH))
        setContentView(root)

        cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        ids = cm.cameraIdList.filter {
            cm.getCameraCharacteristics(it).get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                ?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE) == true
        }
        buildHud()

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) { tryOpen() }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { configureTransform(w, h) }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        stage.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> configureTransform(tv.width, tv.height) }
        (getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(
            object : DisplayManager.DisplayListener {
                override fun onDisplayAdded(id: Int) {}
                override fun onDisplayRemoved(id: Int) {}
                override fun onDisplayChanged(id: Int) {
                    runOnUiThread { updateAspect(); configureTransform(tv.width, tv.height) }
                }
            }, ui)
    }

    override fun onConfigurationChanged(c: Configuration) {
        super.onConfigurationChanged(c)
        buildHud(); updateAspect()
    }

    private fun shape(color: Int, r: Int, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(r).toFloat(); if (stroke != 0) setStroke(dp(2), stroke)
    }

    private fun pill(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t; setTextColor(Color.WHITE); textSize = 12f; typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER; setPadding(dp(14), dp(9), dp(14), dp(9))
        background = shape(0xCC2C2C2E.toInt(), 18); setOnClickListener { onClick() }
    }

    private fun cell(v: View) = FrameLayout(this).apply {
        addView(v, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
    }

    private fun buildHud() {
        hud.removeAllViews()
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        status = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 11f; setShadowLayer(4f, 0f, 0f, Color.BLACK)
        }
        hud.addView(status, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.START)
            .apply { setMargins(dp(12), dp(30), 0, 0) })
        (hist.parent as? ViewGroup)?.removeView(hist)
        hist.visibility = if (histOn) View.VISIBLE else View.GONE
        hud.addView(hist, FrameLayout.LayoutParams(dp(120), dp(56), Gravity.TOP or Gravity.START)
            .apply { setMargins(dp(12), dp(54), 0, 0) })
        timerTv = TextView(this).apply {
            setTextColor(REDC); textSize = 15f; typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(4f, 0f, 0f, Color.BLACK)
            text = if (recording) timerTv.text else ""
        }
        hud.addView(timerTv, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
            .apply { setMargins(0, dp(28), 0, 0) })
        audio = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 32767 }
        hud.addView(audio, FrameLayout.LayoutParams(dp(90), dp(8), Gravity.TOP or Gravity.END)
            .apply { setMargins(0, dp(34), dp(14), 0) })

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(16))
            background = shape(0x99000000.toInt(), if (land) 20 else 0)
        }
        // slider row
        seekRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE }
        seekLabel = TextView(this).apply { setTextColor(ACCENT); textSize = 11f; typeface = Typeface.DEFAULT_BOLD }
        seek = SeekBar(this)
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                if (updatingSeek || !fromUser) return
                val sel = selected ?: return
                prog[sel] = p
                if (sel == Param.ISO || sel == Param.SS) autoExp = false
                if (sel == Param.FOCUS) autoFocus = false
                applyAll()
            }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) { selected?.let { showSeek(it) } }
        })
        autoBtn = pill("AUTO") {
            when (selected) {
                Param.ISO, Param.SS -> autoExp = !autoExp
                Param.FOCUS -> autoFocus = !autoFocus
                Param.EV -> prog[Param.EV] = 50
                Param.ZOOM -> prog[Param.ZOOM] = 0
                else -> {}
            }
            selected?.let { showSeek(it) }; applyAll()
        }
        seekRow.addView(seekLabel, LinearLayout.LayoutParams(dp(60), WRAP))
        seekRow.addView(seek, LinearLayout.LayoutParams(0, WRAP, 1f))
        seekRow.addView(autoBtn)
        panel.addView(seekRow, LinearLayout.LayoutParams(MATCH, WRAP))

        // chips
        val scroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val chipRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(8), 0, dp(8)) }
        chipViews.clear()
        for (p in Param.values()) {
            val chip = TextView(this).apply {
                setTextColor(Color.WHITE); textSize = 13f; typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; setPadding(dp(14), dp(10), dp(14), dp(10))
                setOnClickListener { selected = p; refreshChips(); showSeek(p) }
            }
            chipViews[p] = chip
            chipRow.addView(chip, LinearLayout.LayoutParams(WRAP, WRAP).apply { setMargins(0, 0, dp(8), 0) })
        }
        scroll.addView(chipRow)
        panel.addView(scroll, LinearLayout.LayoutParams(MATCH, WRAP))

        // buttons
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        lensBtn = pill("LENS $lensText") {
            if (!recording && ids.size > 1) { idx = (idx + 1) % ids.size; level = 0; openCamera() }
        }
        torchBtn = pill("TORCH") { torchOn = !torchOn; torchBtn.background = shape(if (torchOn) ACCENT else 0xCC2C2C2E.toInt(), 18); applyAll() }
        val recBtn = FrameLayout(this)
        recBtn.background = shape(Color.TRANSPARENT, 40, Color.WHITE)
        recInner = View(this)
        recBtn.addView(recInner, FrameLayout.LayoutParams(dp(54), dp(54), Gravity.CENTER))
        recBtn.setOnClickListener { if (recording) stopRecording() else startRecording() }
        updateRecUi()
        row.addView(cell(pill("SET") { showSettings() }), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(cell(lensBtn), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(cell(recBtn.also { }).also { }, LinearLayout.LayoutParams(0, dp(76), 1.2f))
        row.addView(cell(pill("PHOTO") { takePhoto() }), LinearLayout.LayoutParams(0, WRAP, 1f))
        row.addView(cell(torchBtn), LinearLayout.LayoutParams(0, WRAP, 1f))
        panel.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        recBtn.layoutParams = FrameLayout.LayoutParams(dp(72), dp(72), Gravity.CENTER)

        hud.addView(panel, FrameLayout.LayoutParams(if (land) dp(360) else MATCH, WRAP,
            if (land) Gravity.END or Gravity.CENTER_VERTICAL else Gravity.BOTTOM))
        ov.grid = gridOn
        refreshChips(); refreshStatus(); selected?.let { showSeek(it) }
    }

    private fun updateRecUi() {
        recInner.background = shape(REDC, if (recording) 8 else 27)
    }

    private fun refreshStatus() {
        val p = presets.getOrNull(curPreset) ?: return
        status.text = "${p.w}x${p.h} · ${p.fps}fps · ${if (hevc) "HEVC" else "H.264"} · ${bitrate(p) / 1_000_000} Mbps"
    }

    private fun refreshChips() {
        for ((p, v) in chipViews) {
            v.text = when (p) {
                Param.ISO -> if (autoExp) "ISO AUTO" else "ISO ${isoVal()}"
                Param.SS -> if (autoExp) "SHUTTER AUTO" else "1/${(1e9 / expNs()).roundToInt()}"
                Param.WB -> wbNames[prog[Param.WB]!!]
                Param.FOCUS -> if (autoFocus) "AF" else "MF ${prog[Param.FOCUS]}"
                Param.EV -> String.format("EV %+.1f", evVal())
                Param.ZOOM -> String.format("%.1fx", zoomVal())
            }
            v.background = shape(0xCC2C2C2E.toInt(), 18, if (p == selected) ACCENT else 0)
        }
    }

    private fun seekMax(p: Param) = when (p) { Param.ISO, Param.SS -> 1000; Param.WB -> 4; else -> 100 }

    private fun showSeek(p: Param) {
        seekRow.visibility = View.VISIBLE
        seekLabel.text = p.name
        updatingSeek = true
        seek.max = seekMax(p); seek.progress = prog[p]!!
        updatingSeek = false
        autoBtn.visibility = View.VISIBLE
        when (p) {
            Param.ISO, Param.SS -> autoBtn.text = if (autoExp) "SET MANUAL" else "SET AUTO"
            Param.FOCUS -> autoBtn.text = if (autoFocus) "SET MANUAL" else "SET AUTO"
            Param.WB -> autoBtn.visibility = View.GONE
            else -> autoBtn.text = "RESET"
        }
    }

    private fun showSettings() {
        val dlg = Dialog(this, android.R.style.Theme_Material_Dialog)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(14), dp(20), dp(14)) }
        fun spinner(title: String, items: List<String>, sel: Int, on: (Int) -> Unit) {
            col.addView(TextView(this).apply { text = title; setTextColor(ACCENT); textSize = 12f })
            val sp = Spinner(this)
            sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
            sp.setSelection(sel, false)
            sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { on(pos) }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
            col.addView(sp)
        }
        fun toggle(title: String, v: Boolean, on: (Boolean) -> Unit) {
            col.addView(Switch(this).apply { text = title; isChecked = v; setOnCheckedChangeListener { _, c -> on(c) } })
        }
        spinner("RESOLUTION / FPS", presets.map { it.label }, curPreset) { i ->
            if (i != curPreset && !recording) {
                curPreset = i; level = 0; computePreviewSize(); refreshStatus(); startPreview()
            }
        }
        spinner("CODEC", listOf("H.264 (compatible)", "HEVC / H.265 (smaller)"), if (hevc) 1 else 0) { hevc = it == 1; refreshStatus() }
        val br = listOf(0, 30, 60, 100)
        spinner("BITRATE", br.map { if (it == 0) "Auto" else "$it Mbps" }, br.indexOf(bitrateMbps).coerceAtLeast(0)) {
            bitrateMbps = br[it]; refreshStatus()
        }
        toggle("Zebra (overexposure stripes)", zebraOn) { zebraOn = it; if (!it && !peakOn) ov.mask = null }
        toggle("Focus peaking (green edges)", peakOn) { peakOn = it; if (!it && !zebraOn) ov.mask = null }
        toggle("Histogram", histOn) { histOn = it; hist.visibility = if (it) View.VISIBLE else View.GONE }
        toggle("Grid (thirds)", gridOn) { gridOn = it; ov.grid = it; ov.invalidate() }
        val rawOk = chars?.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            ?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW) == true
        if (rawOk) toggle("RAW photos (DNG + JPEG)", rawOn) { rawOn = it; level = 0; if (!recording) startPreview() }
        else col.addView(TextView(this).apply { text = "RAW not supported on this lens"; setTextColor(Color.GRAY) })
        col.addView(pill("DONE") { dlg.dismiss() }, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(12) })
        dlg.setContentView(ScrollView(this).apply { addView(col) })
        dlg.show()
    }

    // ================= Lifecycle =================
    override fun onResume() {
        super.onResume()
        val need = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) requestPermissions(need.toTypedArray(), 1) else tryOpen()
    }

    override fun onRequestPermissionsResult(c: Int, p: Array<out String>, r: IntArray) {
        if (r.isNotEmpty() && r.all { it == PackageManager.PERMISSION_GRANTED }) tryOpen()
        else Toast.makeText(this, "Camera & mic permissions are required", Toast.LENGTH_LONG).show()
    }

    override fun onPause() {
        if (recording) stopRecording()
        closeCamera()
        super.onPause()
    }

    override fun onDestroy() { bgThread.quitSafely(); super.onDestroy() }

    private fun tryOpen() {
        if (device == null && tv.isAvailable && ids.isNotEmpty() &&
            checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera()
    }

    // ================= Camera =================
    @Suppress("MissingPermission")
    private fun openCamera() {
        closeCamera()
        val id = ids[idx]
        val c = cm.getCameraCharacteristics(id)
        chars = c
        lensText = lensLabel(c)
        setupPresets()
        runOnUiThread { lensBtn.text = "LENS $lensText"; refreshStatus(); refreshChips() }
        cm.openCamera(id, object : CameraDevice.StateCallback() {
            override fun onOpened(d: CameraDevice) { device = d; startPreview() }
            override fun onDisconnected(d: CameraDevice) { d.close(); device = null }
            override fun onError(d: CameraDevice, e: Int) {
                d.close(); device = null
                runOnUiThread { Toast.makeText(this@MainActivity, "Camera error $e", Toast.LENGTH_SHORT).show() }
            }
        }, handler)
    }

    private fun lensLabel(c: CameraCharacteristics): String {
        val front = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        val f = c.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
        val sz = c.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        val mm = if (f != null && sz != null) "${(f * 43.27f / hypot(sz.width, sz.height)).roundToInt()}mm" else ""
        return (if (front) "FRONT " else "") + mm
    }

    private fun closeCamera() {
        try { session?.close() } catch (_: Exception) {}
        session = null
        device?.close(); device = null
        jpegReader?.close(); jpegReader = null
        rawReader?.close(); rawReader = null
        anaReader?.close(); anaReader = null
    }

    private fun setupPresets() {
        val c = chars!!
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val sizes = map.getOutputSizes(MediaRecorder::class.java).toList()
        val ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES) ?: emptyArray()
        presets.clear()
        for ((n, w, h) in listOf(Triple("720p", 1280, 720), Triple("1080p", 1920, 1080), Triple("4K", 3840, 2160)))
            for (f in listOf(24, 25, 30, 50, 60))
                if (sizes.any { it.width == w && it.height == h } && ranges.any { it.lower <= f && it.upper >= f })
                    presets.add(Preset("$n ${f}fps", w, h, f))
        if (presets.isEmpty()) presets.add(Preset("1080p 30fps", 1920, 1080, 30))
        curPreset = presets.indexOfFirst { it.label == "1080p 30fps" }.coerceAtLeast(0)
        computePreviewSize()
    }

    private fun computePreviewSize() {
        val p = presets[curPreset]
        val map = chars!!.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        previewSize = map.getOutputSizes(SurfaceTexture::class.java)
            .filter { it.width * p.h == it.height * p.w && it.width <= 1920 }
            .maxByOrNull { it.width * it.height } ?: Size(1920, 1080)
        updateAspect()
    }

    private fun updateAspect() {
        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        runOnUiThread {
            if (portrait) stage.setAspect(previewSize.height, previewSize.width)
            else stage.setAspect(previewSize.width, previewSize.height)
        }
    }

    private fun configureTransform(vw: Int, vh: Int) {
        if (vw == 0 || vh == 0) return
        val r = rot()
        val m = Matrix()
        val viewRect = RectF(0f, 0f, vw.toFloat(), vh.toFloat())
        val cx = viewRect.centerX(); val cy = viewRect.centerY()
        if (r == Surface.ROTATION_90 || r == Surface.ROTATION_270) {
            val bufferRect = RectF(0f, 0f, previewSize.height.toFloat(), previewSize.width.toFloat())
            bufferRect.offset(cx - bufferRect.centerX(), cy - bufferRect.centerY())
            m.setRectToRect(viewRect, bufferRect, Matrix.ScaleToFit.FILL)
            val scale = max(vh.toFloat() / previewSize.height, vw.toFloat() / previewSize.width)
            m.postScale(scale, scale, cx, cy)
            m.postRotate(90f * (r - 2), cx, cy)
        } else if (r == Surface.ROTATION_180) m.postRotate(180f, cx, cy)
        tv.setTransform(m)
    }

    private fun sessionCb(ok: (CameraCaptureSession) -> Unit, fail: () -> Unit = {}) =
        object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) = ok(s)
            override fun onConfigureFailed(s: CameraCaptureSession) = fail()
        }

    private fun startPreview() {
        val d = device ?: return
        val st = tv.surfaceTexture ?: return
        val c = chars ?: return
        val p = presets[curPreset]
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        try { session?.close() } catch (_: Exception) {}
        session = null
        jpegReader?.close(); rawReader?.close(); anaReader?.close()
        previewSurface?.release()
        val ps = Surface(st); previewSurface = ps
        val map = c.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!

        val js = map.getOutputSizes(ImageFormat.JPEG).maxByOrNull { it.width * it.height }!!
        val jr = ImageReader.newInstance(js.width, js.height, ImageFormat.JPEG, 2)
        jr.setOnImageAvailableListener({ saveJpeg(it) }, handler)
        jpegReader = jr
        val surfaces = mutableListOf(ps, jr.surface)

        anaSurface = null; anaReader = null
        if (level < 1) {
            val all = map.getOutputSizes(ImageFormat.YUV_420_888).filter { it.width <= 800 }
            val asz = all.filter { it.width * p.h == it.height * p.w }.maxByOrNull { it.width * it.height }
                ?: all.maxByOrNull { it.width * it.height }
            if (asz != null) {
                val ar = ImageReader.newInstance(asz.width, asz.height, ImageFormat.YUV_420_888, 2)
                ar.setOnImageAvailableListener({ analyze(it) }, handler)
                anaReader = ar; anaSurface = ar.surface; surfaces.add(ar.surface)
            }
        }

        rawInSession = false; rawReader = null
        val rawOk = c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
            ?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW) == true
        if (rawOn && rawOk && level < 2) {
            val rs = map.getOutputSizes(ImageFormat.RAW_SENSOR)?.maxByOrNull { it.width * it.height }
            if (rs != null) {
                val rr = ImageReader.newInstance(rs.width, rs.height, ImageFormat.RAW_SENSOR, 2)
                rr.setOnImageAvailableListener({ r ->
                    synchronized(rawLock) { pendingRaw?.close(); pendingRaw = r.acquireNextImage() }
                    tryWriteDng()
                }, handler)
                rawReader = rr; rawInSession = true; surfaces.add(rr.surface)
            }
        }

        d.createCaptureSession(surfaces, sessionCb({ s ->
            session = s
            builder = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(ps); anaSurface?.let { addTarget(it) }
            }
            applyAll()
        }, {
            if (level < 3) {
                level++
                runOnUiThread { Toast.makeText(this, "Stream combo not supported, reducing features", Toast.LENGTH_SHORT).show() }
                startPreview()
            }
        }), handler)
    }

    // ================= Manual values =================
    private fun isoVal(): Int {
        val r = chars?.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: return 100
        val p = prog[Param.ISO]!! / 1000.0
        return (r.lower * (r.upper.toDouble() / r.lower).pow(p)).toInt().coerceIn(r.lower, r.upper)
    }

    private fun expNs(): Long {
        val r = chars?.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: return 16_666_666L
        val denom = 24.0 * (8000.0 / 24.0).pow(prog[Param.SS]!! / 1000.0)
        val fps = presets.getOrNull(curPreset)?.fps ?: 30
        return min((1e9 / denom).toLong(), (1e9 / fps).toLong()).coerceIn(r.lower, r.upper)
    }

    private fun evIdx(): Int {
        val r = chars?.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: return 0
        return r.lower + ((r.upper - r.lower) * prog[Param.EV]!! / 100f).roundToInt()
    }

    private fun evVal(): Float {
        val step = chars?.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
        return evIdx() * step
    }

    private fun zoomVal(): Float {
        val mz = min(chars?.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f, 8f)
        return 1f + (mz - 1f) * prog[Param.ZOOM]!! / 100f
    }

    private fun applySettings(b: CaptureRequest.Builder, still: Boolean) {
        val c = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        if (!autoExp) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, isoVal())
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs())
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIdx())
        }
        val minFocus = c.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        if (!autoFocus && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, minFocus * prog[Param.FOCUS]!! / 100f)
        } else b.set(CaptureRequest.CONTROL_AF_MODE,
            if (recording) CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO
            else CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        b.set(CaptureRequest.CONTROL_AWB_MODE, wbModes[prog[Param.WB]!!])

        val ar = c.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)
        if (ar != null) {
            val z = zoomVal()
            val w = (ar.width() / z).toInt(); val h = (ar.height() / z).toInt()
            val l = ar.left + (ar.width() - w) / 2; val t = ar.top + (ar.height() - h) / 2
            b.set(CaptureRequest.SCALER_CROP_REGION, Rect(l, t, l + w, t + h))
        }
        val hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        if (hasFlash && !still) b.set(CaptureRequest.FLASH_MODE,
            if (torchOn) CameraMetadata.FLASH_MODE_TORCH else CameraMetadata.FLASH_MODE_OFF)
        if (!still) {
            val fps = presets.getOrNull(curPreset)?.fps ?: 30
            val ranges = c.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
            val r = ranges?.firstOrNull { it.lower == fps && it.upper == fps }
                ?: ranges?.firstOrNull { it.upper == fps }
            if (r != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, r)
        }
        runOnUiThread { if (chipViews.isNotEmpty()) refreshChips() }
    }

    private fun applyAll() {
        val b = builder ?: run { refreshChips(); return }
        try {
            applySettings(b, false)
            session?.setRepeatingRequest(b.build(), null, handler)
        } catch (_: Exception) {}
    }

    // ================= Orientation =================
    private fun orient(): Int {
        val c = chars ?: return 0
        val sens = c.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        val r = rot() * 90
        val front = c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_FRONT
        return if (front) (sens + r) % 360 else (sens - r + 360) % 360
    }

    private fun exifOrient() = when (orient()) {
        90 -> ExifInterface.ORIENTATION_ROTATE_90
        180 -> ExifInterface.ORIENTATION_ROTATE_180
        270 -> ExifInterface.ORIENTATION_ROTATE_270
        else -> ExifInterface.ORIENTATION_NORMAL
    }

    // ================= Analysis (histogram / zebra / peaking) =================
    private fun analyze(r: ImageReader) {
        val img = r.acquireLatestImage() ?: return
        try {
            if (++anaCount % 3 != 0) return
            if (!zebraOn && !peakOn && !histOn) return
            val w = img.width; val h = img.height
            val pl = img.planes[0]; val rs = pl.rowStride; val buf = pl.buffer
            val bins = IntArray(64)
            val px = if (zebraOn || peakOn) IntArray(w * h) else null
            for (y in 0 until h) {
                val row = y * rs
                for (x in 0 until w) {
                    val l = buf.get(row + x).toInt() and 0xFF
                    bins[l shr 2]++
                    if (px != null) {
                        if (zebraOn && l >= 235 && (((x + y) shr 3) and 1) == 0) px[y * w + x] = 0xFFFF2D2D.toInt()
                        else if (peakOn && x < w - 1 && y < h - 1) {
                            val dx = abs(l - (buf.get(row + x + 1).toInt() and 0xFF))
                            val dy = abs(l - (buf.get(row + rs + x).toInt() and 0xFF))
                            if (dx + dy > 48) px[y * w + x] = 0xFF00E676.toInt()
                        }
                    }
                }
            }
            var bmp: Bitmap? = null
            if (px != null) {
                val b0 = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
                val deg = orient()
                bmp = if (deg != 0) {
                    val m = Matrix(); m.postRotate(deg.toFloat())
                    Bitmap.createBitmap(b0, 0, 0, w, h, m, false)
                } else b0
            }
            runOnUiThread { ov.mask = bmp; ov.invalidate(); hist.bins = bins; hist.invalidate() }
        } catch (_: Exception) {
        } finally { img.close() }
    }

    // ================= Photo =================
    private fun takePhoto() {
        val d = device ?: return; val s = session ?: return; val jr = jpegReader ?: return
        if (recording) return
        try {
            val b = d.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
            b.addTarget(jr.surface)
            val rr = rawReader
            val withRaw = rawInSession && rr != null
            if (withRaw) b.addTarget(rr!!.surface)
            applySettings(b, true)
            b.set(CaptureRequest.JPEG_ORIENTATION, orient())
            b.set(CaptureRequest.JPEG_QUALITY, 100.toByte())
            s.capture(b.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureCompleted(se: CameraCaptureSession, rq: CaptureRequest, res: TotalCaptureResult) {
                    if (withRaw) { synchronized(rawLock) { pendingRes = res }; tryWriteDng() }
                }
            }, handler)
        } catch (_: Exception) {}
    }

    private fun saveJpeg(reader: ImageReader) {
        val img = reader.acquireNextImage() ?: return
        val buf = img.planes[0].buffer
        val bytes = ByteArray(buf.remaining()).also { buf.get(it) }
        img.close()
        val v = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "IMG_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCam")
        }
        contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)?.let { uri ->
            contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
            runOnUiThread { Toast.makeText(this, "Photo saved", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun tryWriteDng() {
        var img: Image? = null; var res: TotalCaptureResult? = null
        synchronized(rawLock) {
            if (pendingRaw != null && pendingRes != null) {
                img = pendingRaw; res = pendingRes; pendingRaw = null; pendingRes = null
            }
        }
        val i = img ?: return; val r = res ?: return
        try {
            val dng = DngCreator(chars!!, r)
            dng.setOrientation(exifOrient())
            val v = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "RAW_${System.currentTimeMillis()}.dng")
                put(MediaStore.Images.Media.MIME_TYPE, "image/x-adobe-dng")
                put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ProCam")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
            if (uri != null) contentResolver.openOutputStream(uri)?.use { dng.writeImage(it, i) }
            dng.close()
            runOnUiThread { Toast.makeText(this, "RAW saved", Toast.LENGTH_SHORT).show() }
        } catch (_: Exception) {
        } finally { i.close() }
    }

    // ================= Video =================
    private fun bitrate(p: Preset): Int {
        if (bitrateMbps > 0) return bitrateMbps * 1_000_000
        val base = p.w.toLong() * p.h * p.fps / 4
        return min(100_000_000L, if (hevc) base / 2 else base).toInt()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!recording) return
            val s = (SystemClock.elapsedRealtime() - recStart) / 1000
            timerTv.text = "● %02d:%02d".format(s / 60, s % 60)
            audio.progress = try { recorder?.maxAmplitude ?: 0 } catch (_: Exception) { 0 }
            ui.postDelayed(this, 150)
        }
    }

    private fun startRecording() {
        val d = device ?: return
        val ps = previewSurface ?: return
        val p = presets[curPreset]
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VID_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ProCam")
        }
        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v) ?: return
        val pfd = contentResolver.openFileDescriptor(uri, "w") ?: return
        recPfd = pfd
        fun make(h265: Boolean) = MediaRecorder().apply {
            setAudioSource(MediaRecorder.AudioSource.MIC)
            setVideoSource(MediaRecorder.VideoSource.SURFACE)
            setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            setOutputFile(pfd.fileDescriptor)
            setVideoEncodingBitRate(bitrate(p))
            setVideoFrameRate(p.fps)
            setVideoSize(p.w, p.h)
            setVideoEncoder(if (h265) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            setAudioEncodingBitRate(192_000)
            setAudioSamplingRate(48_000)
            setOrientationHint(orient())
            prepare()
        }
        val rec = try { make(hevc) } catch (e: Exception) {
            try { make(false) } catch (e2: Exception) {
                contentResolver.delete(uri, null, null)
                Toast.makeText(this, "Recording not supported at this setting", Toast.LENGTH_LONG).show()
                return
            }
        }
        recorder = rec
        try { session?.close() } catch (_: Exception) {}
        val surfaces = mutableListOf(ps, rec.surface)
        anaSurface?.let { surfaces.add(it) }
        d.createCaptureSession(surfaces, sessionCb({ s ->
            session = s
            builder = d.createCaptureRequest(CameraDevice.TEMPLATE_RECORD).apply {
                addTarget(ps); addTarget(rec.surface); anaSurface?.let { addTarget(it) }
            }
            recording = true
            applyAll()
            rec.start()
            recStart = SystemClock.elapsedRealtime()
            runOnUiThread { updateRecUi(); ui.post(tick) }
        }, {
            cleanupRecorder()
            runOnUiThread { Toast.makeText(this, "Resolution/FPS not supported for video", Toast.LENGTH_LONG).show() }
            level = max(level, 1); startPreview()
        }), handler)
    }

    private fun stopRecording() {
        recording = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (_: Exception) {}
        try { recorder?.stop() } catch (_: Exception) {}
        cleanupRecorder()
        runOnUiThread {
            updateRecUi(); timerTv.text = ""; audio.progress = 0
            Toast.makeText(this, "Video saved", Toast.LENGTH_SHORT).show()
        }
        startPreview()
    }

    private fun cleanupRecorder() {
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { recPfd?.close() } catch (_: Exception) {}
        recPfd = null
    }
}
